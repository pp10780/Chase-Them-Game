To compile:

 - Run 'make' on the root directory

To execute:
 - To maximize the player's experience it is recommended that the terminal where the user will play the game is full-screened
 - Open at least 4 distinct terminals in the 'bin' directory -> "cd bin"
 - Run the server by running -> "./server"
 - Run the timer by running -> "./timer"
 - Run the bot_client by running -> "./bots {N_BOTS} /tmp/sock_16"
 - Play the game by running -> "./client /tmp/sock_16"
   - Initially the program will prompt you to choose a letter and the game will only start when you choose a valid letter that no one else playing the game is using.
   - Play the game and have fun!

